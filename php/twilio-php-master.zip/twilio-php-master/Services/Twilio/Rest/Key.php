<?php

class Services_Twilio_Rest_Key extends Services_Twilio_InstanceResource
{
}

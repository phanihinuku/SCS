<?php

class Services_Twilio_Rest_Monitor_Alert extends Services_Twilio_MonitorInstanceResource {

}

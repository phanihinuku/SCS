<?php

class Services_Twilio_Rest_Addresses
    extends Services_Twilio_ListResource
{
}
